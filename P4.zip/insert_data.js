var mysql = require('mysql');  
var con = mysql.createConnection({  
host: "localhost",  
user: "root",  
password: "",  
database: "awamad"  
});  
con.connect(function(err) {    
	if(err)
		throw err;
console.log("Connected!");  
var sql = "INSERT INTO dept (department_id,department_name,department_count,department_hod) VALUES ?";  
var values = [  
['1','CSE','40','Suman'],  
['2', 'IT', '35', 'Vaibhav'],  
['3', 'CIVIL', '20','Kiran']  
];  
con.query(sql, [values], function (err, result) {   
	if(err)
		throw err;
console.log("Number of records inserted: " + result.affectedRows);  
});  
});  
