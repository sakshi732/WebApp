var mysql = require('mysql');  
var con = mysql.createConnection({  
host: "localhost",  
user: "root",  
password: "",  
database: "AWAMAD"  
});  
con.connect(function(err) {  
console.log("Connected!");  
var sql = "CREATE TABLE dept(department_id INT, department_name VARCHAR(255), department_count INT(3), department_hod VARCHAR(255))";  
con.query(sql, function (err, result) {  
console.log("Table created");  
});  
});  